-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 24 Sty 2019, 00:33
-- Wersja serwera: 10.1.37-MariaDB
-- Wersja PHP: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `biblioteka`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `bibliotekarz_rejestracja`
--

CREATE TABLE `bibliotekarz_rejestracja` (
  `id` int(5) NOT NULL,
  `imie` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `nazwisko` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `nazwa_usera` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `haslo` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `email` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `kontakt` varchar(50) COLLATE ucs2_polish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ucs2 COLLATE=ucs2_polish_ci;

--
-- Zrzut danych tabeli `bibliotekarz_rejestracja`
--

INSERT INTO `bibliotekarz_rejestracja` (`id`, `imie`, `nazwisko`, `nazwa_usera`, `haslo`, `email`, `kontakt`) VALUES
(1, 'Stary', 'Bibliotekarz', 'starytyp', 'haslo', 'nie@wiem.XD', '987654321');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `dodaj_ksiazke`
--

CREATE TABLE `dodaj_ksiazke` (
  `id` int(5) NOT NULL,
  `tytul` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `imie_autora` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `nazwisko_autora` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `wydawnictwo` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `rok_wydania` smallint(4) NOT NULL,
  `dostepnosc` varchar(20) COLLATE ucs2_polish_ci NOT NULL,
  `liczba_sztuk` int(20) NOT NULL,
  `nazwa_pracownika` varchar(50) COLLATE ucs2_polish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ucs2 COLLATE=ucs2_polish_ci;

--
-- Zrzut danych tabeli `dodaj_ksiazke`
--

INSERT INTO `dodaj_ksiazke` (`id`, `tytul`, `imie_autora`, `nazwisko_autora`, `wydawnictwo`, `rok_wydania`, `dostepnosc`, `liczba_sztuk`, `nazwa_pracownika`) VALUES
(6, 'Taka sztuka dla sztuki', 'Bartosz', 'H', 'WspaniaÅ‚e', 2019, '50', 50, 'starytyp'),
(7, 'Sztuka WOjny', 'asdasdasd', 'asdasda', 'asdasd', 0, '50', 50, 'starytyp');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pozyczanie`
--

CREATE TABLE `pozyczanie` (
  `id` int(5) NOT NULL,
  `nr_indexu` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `student_imie` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `student_sem` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `student_kontakt` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `student_email` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `ksiazka_tytul` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `ksiazka_data_wypoz` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `ksiazka_data_oddania` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `nazwa_usera` varchar(50) COLLATE ucs2_polish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ucs2 COLLATE=ucs2_polish_ci;

--
-- Zrzut danych tabeli `pozyczanie`
--

INSERT INTO `pozyczanie` (`id`, `nr_indexu`, `student_imie`, `student_sem`, `student_kontakt`, `student_email`, `ksiazka_tytul`, `ksiazka_data_wypoz`, `ksiazka_data_oddania`, `nazwa_usera`) VALUES
(18, '213211', 'Bartosz H', '122121', '123123123', 'email@email.pl', 'Taka sztuka dla sztuki', '22-01-2019', '22-01-2019', 'User1'),
(19, '213211', 'Bartosz H', '122121', '123123123', 'email@email.pl', 'Sztuka WOjny', '22-01-2019', '', 'User1');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `student_rejestracja`
--

CREATE TABLE `student_rejestracja` (
  `id` int(5) NOT NULL,
  `imie` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `nazwisko` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `nazwa_usera` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `haslo` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `email` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `kontakt` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `sem` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `nr_indexu` varchar(50) COLLATE ucs2_polish_ci NOT NULL,
  `status` varchar(3) COLLATE ucs2_polish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ucs2 COLLATE=ucs2_polish_ci;

--
-- Zrzut danych tabeli `student_rejestracja`
--

INSERT INTO `student_rejestracja` (`id`, `imie`, `nazwisko`, `nazwa_usera`, `haslo`, `email`, `kontakt`, `sem`, `nr_indexu`, `status`) VALUES
(1, 'Bartosz', 'H', 'User1', 'haslo', 'email@email.pl', '123123123', '122121', '213211', 'TAK'),
(2, 'WÅ‚adysÅ‚aw', 'Kot', 'koty', 'nieznam', 'koty@koty.pl', '357159357', '2', '321654', 'NIE');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `bibliotekarz_rejestracja`
--
ALTER TABLE `bibliotekarz_rejestracja`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `dodaj_ksiazke`
--
ALTER TABLE `dodaj_ksiazke`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `pozyczanie`
--
ALTER TABLE `pozyczanie`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `student_rejestracja`
--
ALTER TABLE `student_rejestracja`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT dla tabeli `bibliotekarz_rejestracja`
--
ALTER TABLE `bibliotekarz_rejestracja`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `dodaj_ksiazke`
--
ALTER TABLE `dodaj_ksiazke`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT dla tabeli `pozyczanie`
--
ALTER TABLE `pozyczanie`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT dla tabeli `student_rejestracja`
--
ALTER TABLE `student_rejestracja`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
