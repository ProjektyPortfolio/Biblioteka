<?php
session_start();
if(!isset($_SESSION["bibliotekarz"]))
{
	?>
	<script type="text/javascript">
	window.location="login_bibliotekarz.php";
	</script>
	
	
	<?php
}
include "polaczenie.php";
include "header.php";
?>


        <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                <div class="page-title">
                    <div class="title_left">
                        <h3>Profil bibliotekarza</h3>
                    </div>

                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Pokaż i szukaj książki</h2>

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
							<form name="form1 action="" method="post" placeholder="Wpisz tytuł książki">
							<input type="text" name="t1" class="form-control"> 
							<input type="submit" name="submit1" value="szukaj książek" class="btn btn-default">
							</form>
                               <?php
							   if(isset($_POST["submit1"]))
							   {
								$res=mysqli_query($link,"select * from dodaj_ksiazke where tytul like('$_POST[t1]%')");
							   echo "<table class='table table-bordered'>";
							   echo "<tr>";
							   echo "<th>"; echo "Tytuł"; echo "</th>";
							   echo "<th>"; echo "Imię autora"; echo "</th>";
							   echo "<th>"; echo "Nazwisko autora"; echo "</th>";
							   echo "<th>"; echo "Wydawnictwo"; echo "</th>";
							   echo "<th>"; echo "Rok wydania"; echo "</th>";
							   echo "<th>"; echo "Dostępne egzemplarze"; echo "</th>";
							   echo "<th>"; echo "Łączna ilość egzemplarzy"; echo "</th>";
							   echo "</tr>";
							   while ($row = mysqli_fetch_array($res))
							   {
								echo "<tr>";   
							   echo "<td>"; echo $row["tytul"]; echo "</td>";
							   echo "<td>"; echo $row["imie_autora"]; echo "</td>";
							   echo "<td>"; echo $row["nazwisko_autora"]; echo "</td>";
							   echo "<td>"; echo $row["wydawnictwo"]; echo "</td>";
							   echo "<td>"; echo $row["rok_wydania"]; echo "</td>";
							   echo "<td>"; echo $row["dostepnosc"]; echo "</td>";
							   echo "<td>"; echo $row["liczba_sztuk"]; echo "</td>"; 
								echo "</tr>";							   
							   }
							   echo "</table>";   
							   }
							   else{
							   $res=mysqli_query($link,"select * from dodaj_ksiazke");
							   echo "<table class='table table-bordered'>";
							   echo "<tr>";
							   echo "<th>"; echo "Tytuł"; echo "</th>";
							   echo "<th>"; echo "Imię autora"; echo "</th>";
							   echo "<th>"; echo "Nazwisko autora"; echo "</th>";
							   echo "<th>"; echo "Wydawnictwo"; echo "</th>";
							   echo "<th>"; echo "Rok wydania"; echo "</th>";
							   echo "<th>"; echo "Dostępne egzemplarze"; echo "</th>";
							   echo "<th>"; echo "Łączna ilość egzemplarzy"; echo "</th>";
							   echo "</tr>";
							   while ($row = mysqli_fetch_array($res))
							   {
								echo "<tr>";   
							   echo "<td>"; echo $row["tytul"]; echo "</td>";
							   echo "<td>"; echo $row["imie_autora"]; echo "</td>";
							   echo "<td>"; echo $row["nazwisko_autora"]; echo "</td>";
							   echo "<td>"; echo $row["wydawnictwo"]; echo "</td>";
							   echo "<td>"; echo $row["rok_wydania"]; echo "</td>";
							   echo "<td>"; echo $row["dostepnosc"]; echo "</td>";
							   echo "<td>"; echo $row["liczba_sztuk"]; echo "</td>"; 
								echo "</tr>";							   
							   }
							   echo "</table>";
							   }
							   ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->

<?php
include "footer.php";
      
?>