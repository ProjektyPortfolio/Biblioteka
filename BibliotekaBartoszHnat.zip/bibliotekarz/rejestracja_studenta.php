<?php
session_start();
if(!isset($_SESSION["bibliotekarz"]))
{
	?>
	<script type="text/javascript">
	window.location="login_bibliotekarz.php";
	</script>
	
	
	<?php
}
include "header.php";
include "polaczenie.php";
?>


        <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                <div class="page-title">
                    <div class="title_left">
                        <h3>Profil bibliotekarza</h3>
                    </div>

                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Pożycz książkę</h2>

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
            <h2>Rejestracja użytkownika</h2><br>

            <div>
                <input type="text" class="form-control" placeholder="Imię" name="imie" required=""/>
            </div>
            <div>
                <input type="text" class="form-control" placeholder="Nazwisko" name="nazwisko" required=""/>
            </div>

            <div>
                <input type="text" class="form-control" placeholder="Nazwa usera" name="nazwa_usera" required=""/>
            </div>
            <div>
                <input type="password" class="form-control" placeholder="Hasło" name="haslo" required=""/>
            </div>
            <div>
                <input type="text" class="form-control" placeholder="E-mail" name="email" required=""/>
            </div>
            <div>
                <input type="text" class="form-control" placeholder="Kontakt" name="kontakt" required=""/>
            </div>
            <div>
                <input type="text" class="form-control" placeholder="Semestr" name="sem" required=""/>
            </div>
            <div>
                <input type="text" class="form-control" placeholder="Nr indexu" name="nr_indexu" required=""/>
            </div>
            <div class="col-lg-12  col-lg-push-3">
                <input class="btn btn-default submit " type="submit" name="submit1" value="Register">
            </div>

        </form>
    </section>



</div>

<?php
if(isset($_POST["submit1"]))
{
	
	
	mysqli_query($link,"insert into student_rejestracja values('','$_POST[imie]','$_POST[nazwisko]','$_POST[nazwa_usera]','$_POST[haslo]','$_POST[email]','$_POST[kontakt]','$_POST[sem]','$_POST[nr_indexu]','NIE')");

	?>
	<div class="alert alert-success col-lg-12 col-lg-push-0">
    Rejestracja zakończyła się sukcesem, otrzymasz maila, gdy twoje konto zostanie zakceptowane.
</div>
	<?php
	
	}
?>
                      </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->

<?php
include "footer.php";
      
?>
