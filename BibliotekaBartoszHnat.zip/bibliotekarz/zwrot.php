<?php
include "polaczenie.php";
$id=$_GET["id"];
$a=date("d-m-Y");
$res=mysqli_query($link,"update pozyczanie set ksiazka_data_oddania='$a' where id=$id");
?>

<script type="text/javascript">
window.location="oddanie_ksiazki.php";
</script>