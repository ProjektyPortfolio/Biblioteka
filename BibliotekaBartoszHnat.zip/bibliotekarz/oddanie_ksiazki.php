<?php
session_start();
if(!isset($_SESSION["bibliotekarz"]))
{
	?>
	<script type="text/javascript">
	window.location="login_bibliotekarz.php";
	</script>
	
	
	<?php
}
include "polaczenie.php";
include "header.php";
?>


        <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                <div class="page-title">
                    <div class="title_left">
                        <h3>Profil bibliotekarza</h3>
                    </div>

                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Oddanie książki</h2>

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
							<form name="form1" action="" method="post">
							<table class="table table-bordered">
							<tr>
								<td><select name="poz" class="form-control">
							<?php
							$res=mysqli_query($link,"select nr_indexu from pozyczanie where ksiazka_data_oddania=''");
							while($row=mysqli_fetch_array($res))
							{
								echo "<option>";
								echo $row["nr_indexu"];
								echo "</option>";
							}
							?>
								</select></td>
								<td>
								<input type="submit" name="submit1" value="szukaj" class="form-control">
								</td>
							
							</tr>
							</table>
									<?php
									if(isset($_POST["submit1"]))
									{
										$res=mysqli_query($link,"select * from pozyczanie where nr_indexu='$_POST[poz]'");
										echo "<table class='table table-bordered'>";
										echo "<tr>";
										echo "<th>"; echo "Nr indexu"; echo "</th>";
										echo "<th>"; echo "Imię studenta"; echo "</th>";
										echo "<th>"; echo "Semestr"; echo "</th>";
										echo "<th>"; echo "Kontakt"; echo "</th>";
										echo "<th>"; echo "E-mail"; echo "</th>";
										echo "<th>"; echo "Tytuł"; echo "</th>";
										echo "<th>"; echo "Data wypożyczenia"; echo "</th>";
										echo "<th>";
										echo "Zwrot książki";
										echo "</th>";
										echo "</tr>";
							while($row=mysqli_fetch_array($res))
							{
								echo "<tr>";
								echo "<td>"; echo $row["nr_indexu"]; echo "</td>";
								echo "<td>"; echo $row["student_imie"]; echo "</td>";
								echo "<td>"; echo $row["student_sem"]; echo "</td>";
								echo "<td>"; echo $row["student_kontakt"]; echo "</td>";
								echo "<td>"; echo $row["student_email"]; echo "</td>";
								echo "<td>"; echo $row["ksiazka_tytul"]; echo "</td>";
								echo "<td>"; echo $row["ksiazka_data_wypoz"]; echo "</td>";
								echo "<td>"; ?> <a href="zwrot.php?id=<?php echo $row["id"]; ?>">Zwrot ksiązki</a><?php echo "</td>";
								echo "</tr>";
									}
									echo "</table>";
									}
									
									?>
							</form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->

<?php
include "footer.php";
      
?>