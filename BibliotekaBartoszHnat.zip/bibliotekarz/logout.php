<?php
session_start();
unset($_SESSION["bibliotekarz"]);
?>
<script type="text/javascript">
window.location="login_bibliotekarz.php";
</script>