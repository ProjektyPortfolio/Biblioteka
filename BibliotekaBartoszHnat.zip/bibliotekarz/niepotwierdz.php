<?php
include "polaczenie.php";
$id=$_GET["id"];
mysqli_query($link,"update student_rejestracja set status='NIE' where id=$id");
?>

<script type="text/javascript">
window.location="pokaz_studentow.php";
</script>