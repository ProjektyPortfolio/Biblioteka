<?php
session_start();
include "polaczenie.php"
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Logowanie bibliotekarza | Biblioteka </title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/custom.min.css" rel="stylesheet">
</head>

<br>

<div class="col-lg-12 text-center ">
    <h1 style="font-family:Lucida Console">Biblioteka</h1>
</div>

<br>

<body class="login">


<div class="login_wrapper">

    <section class="login_content">
        <form name="form1" action="" method="post">
            <h1>Logowanie bibliotekarza</h1>

            <div>
                <input type="text" name="nazwa_usera" class="form-control" placeholder="Nazwa użytkownika" required=""/>
            </div>
            <div>
                <input type="password" name="haslo" class="form-control" placeholder="Hasło" required=""/>
            </div>
            <div>

                <input class="btn btn-default submit" type="submit" name="submit1" value="Zaloguj się">
                <a class="reset_pass" href="#">Zapomniałeś hasła?</a>
            </div>

            <div class="clearfix"></div>

            <div class="separator">
                

                <div class="clearfix"></div>
                <br/>


            </div>
        </form>
    </section>


</div>
<?php
if(isset($_POST["submit1"]))
{
	$count=0;
 $res=mysqli_query($link,"select * from bibliotekarz_rejestracja where nazwa_usera='$_POST[nazwa_usera]' && haslo='$_POST[haslo]'");	
$count=mysqli_num_rows($res);

if($count==0)
{
	?>
	<div class="alert alert-danger col-lg-12 col-lg-push-0">
    <strong style="color:white">Nieprawidłowa</strong> nazwa użytkownika lub hasło.
</div>
<?php
}
else
{
	$_SESSION["bibliotekarz"]=$_POST["nazwa_usera"];
	?>
<script type="text/javascript">
window.location="pokaz_studentow.php";	
</script>
	<?php
}
 }
?>




</body>
</html>