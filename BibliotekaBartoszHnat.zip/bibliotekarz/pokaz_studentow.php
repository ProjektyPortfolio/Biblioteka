<?php
session_start();
if(!isset($_SESSION["bibliotekarz"]))
{
	?>
	<script type="text/javascript">
	window.location="login_bibliotekarz.php";
	</script>
	
	
	<?php
}
include "header.php";
include "polaczenie.php";
?>


        <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                <div class="page-title">
                    <div class="title_left">
                        <h3>Profil bibliotekarza</h3>
                    </div>

                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Pokaż listę studentów</h2>

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">

							<?php
                            $res=mysqli_query($link,"select * from student_rejestracja");
                            echo "<table class='table table-bordered'>";
							echo "<tr>";
							
							echo "<th>"; echo "Imie"; echo "</th>";
							echo "<th>"; echo "Nazwisko"; echo "</th>";
							echo "<th>"; echo "Nazwa uzytkownika"; echo "</th>";
							echo "<th>"; echo "E-mail"; echo "</th>";
							echo "<th>"; echo "Kontakt"; echo "</th>";
							echo "<th>"; echo "Sem"; echo "</th>";
							echo "<th>"; echo "Nr indexu"; echo "</th>";
							echo "<th>"; echo "Status"; echo "</th>";
							echo "<th>"; echo "Potwierdz"; echo "</th>";
							echo "<th>"; echo "Nie potwierdzaj"; echo "</th>";
							echo "</tr>";
							
							while($row=mysqli_fetch_array($res))
							{
							echo "<tr>";
							
							echo "<td>"; echo $row["imie"]; echo "</td>";
							echo "<td>"; echo $row["nazwisko"]; echo "</td>";
							echo "<td>"; echo $row["nazwa_usera"]; echo "</td>";
							echo "<td>"; echo $row["email"]; echo "</td>";
							echo "<td>"; echo $row["kontakt"]; echo "</td>";
							echo "<td>"; echo $row["sem"]; echo "</td>";
							echo "<td>"; echo $row["nr_indexu"]; echo "</td>";
							echo "<td>"; echo $row["status"]; echo "</td>";	
							echo "<td>"; ?> <a href="potwierdz.php?id=<?php echo $row["id"];?>">Potwierdz</a> <?php  echo"</td>";
							echo "<td>"; ?> <a href="niepotwierdz.php?id=<?php echo $row["id"];?>">Nie potwierdzaj</a> <?php  echo"</td>";
							echo "</tr>";
							}
							echo "</table>";
							?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->

<?php
include "footer.php";
      
?>