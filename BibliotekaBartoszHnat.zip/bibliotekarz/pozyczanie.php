<?php

session_start();
if(!isset($_SESSION["bibliotekarz"]))
{
	?>
	<script type="text/javascript">
	window.location="login_bibliotekarz.php";
	</script>
	
	
	<?php
}
include "header.php";
include "polaczenie.php";
?>


        <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                <div class="page-title">
                    <div class="title_left">
                        <h3>Profil bibliotekarza</h3>
                    </div>

                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Pożycz książkę</h2>

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <form name="form1" action="" method="post">
								<table>
								<tr>
								
									<td>
									<select name="poz" class="form-control selectpicker">
									<?php
									$res=mysqli_query($link,"select nr_indexu from student_rejestracja");
									while($row=mysqli_fetch_array($res))
									{
											echo "<option>";
											echo $row["nr_indexu"];
											echo "</option>";
									}
								
								
									?>
									</select>
									</td>
									<td>
									<input type="submit" name="submit1" value="search" class="form-control btn btn-default" style="margin-top: 5px;">
									</td>
								
								</tr>
								</table>
								
								
								<?php
								if (isset($_POST["submit1"])){
								$res5=mysqli_query($link,"select * from student_rejestracja where nr_indexu='$_POST[poz]'");
								while($row5=mysqli_fetch_array($res5))
								{
									$imie=$row5["imie"];
									$nazwisko=$row5["nazwisko"];
									$nazwa_usera=$row5["nazwa_usera"];
									$email=$row5["email"];
									$kontakt=$row5["kontakt"];
									$sem=$row5["sem"];
									$nr_indexu=$row5["nr_indexu"];
									$_SESSION["nr_indexu"]=$nr_indexu;
									$_SESSION["nazwa_usera"]=$nazwa_usera;
									
								}
								?>
								<table class="table table-bordered">
							<tr>
							<td><input type="text" class="form-control" placeholder="Numer Indexu" name="nr_indexu" value="<?php echo $nr_indexu; ?>" disabled></td>
							</tr>
							
							<tr>
							<td><input type="text" class="form-control" placeholder="Imię studenta" name="student_imie" value="<?php echo $imie,' ',$nazwisko ?>" required></td>
							</tr>
							
							<tr>
							<td><input type="text" class="form-control" placeholder="Rocznik SEM" name="student_sem" value="<?php echo $sem; ?>" required></td>
							</tr>
							
							<tr>
							<td><input type="text" class="form-control" placeholder="Kontakt studenta" name="student_kontakt" value="<?php echo $kontakt; ?>" required></td>
							</tr>
							
							<tr>
							<td><input type="text" class="form-control" placeholder="Adres e-mail" name="student_email" value="<?php echo $email; ?>" required></td>
							</tr>
							
							<tr>
							 <td>
								<select name="tytul" class="form-control selectpicker">
								<?php
								$res=mysqli_query($link,"select tytul from dodaj_ksiazke");
								while($row=mysqli_fetch_array($res))
								{
								echo "<option>";
								
								echo $row["tytul"];
								
								echo "</option>";	
								}
								?>
								</select>
								</td>
								</tr>
								<tr>
								
							<td><input type="text" class="form-control" placeholder="Data wypozyczenia" name="ksiazka_data_wypoz" value="<?php echo date("d-m-Y"); ?>" required></td>
							</tr>
							
							<tr>
							<td><input type="text" class="form-control" placeholder="Nazwa użytkownika" name="nazwa_usera" value="<?php echo $nazwa_usera; ?>" disabled></td>
							</tr>
							
							<tr>
							<td><input type="submit" value="Pożycz książkę"
							           name="submit2" class="form-control btn btn-default">
									   </td>
							</tr>
							
							
							
							</table>
								<?php
								}
								
								?>
								</form>
								<?php
								if(isset($_POST["submit2"]))
								{
								mysqli_query($link,"insert into pozyczanie values('','$_SESSION[nr_indexu]','$_POST[student_imie]','$_POST[student_sem]','$_POST[student_kontakt]','$_POST[student_email]','$_POST[tytul]','$_POST[ksiazka_data_wypoz]','','$_SESSION[nazwa_usera]')");
								var_dump($_POST);
								?>
								<script type="text/javascript";
								
								alert("Sukces, książka została wypożyczona!");
								window.location.href=window.location.href;
								</script>
								<?php
								
								}
								
								?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->

<?php
include "footer.php";
      
?>